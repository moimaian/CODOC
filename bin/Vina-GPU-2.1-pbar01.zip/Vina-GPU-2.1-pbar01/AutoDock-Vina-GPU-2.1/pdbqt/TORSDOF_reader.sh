#!/bin/bash

# Define the folder where the .pdbqt files are located
folder_path="./"

# Initialize variables for the sum of TORSDOF values and the count of files
total_torsdof=0
file_count=0

# Loop through all .pdbqt files in the specified folder
for file in "$folder_path"/*.pdbqt; do
    # Check if the file exists (in case no .pdbqt files are found)
    if [ ! -f "$file" ]; then
        echo "No .pdbqt files found in the folder."
        exit 1
    fi
    
    # Extract the TORSDOF value from the file (make sure it's a number)
    torsdof_value=$(grep "TORSDOF" "$file" | awk '{print $2}')
    
    # Check if a valid TORSDOF value was found (and if it's a number)
    if [[ "$torsdof_value" =~ ^[0-9]+$ ]]; then
        total_torsdof=$(echo "$total_torsdof + $torsdof_value" | bc)
        file_count=$((file_count + 1))
    else
        echo "Invalid or missing TORSDOF value in $file"
    fi
done

# Calculate the average if any files were processed
if [ "$file_count" -gt 0 ]; then
    avg_torsdof=$(echo "scale=2; $total_torsdof / $file_count" | bc)
    
    # Write the result to TORSDOF_avg.txt
    echo "Average TORSDOF: $avg_torsdof" > "$folder_path/TORSDOF_avg.txt"
    
    echo "Average TORSDOF written to TORSDOF_avg.txt"
else
    echo "No valid TORSDOF values found."
fi

