# Vina-GPU 2.1
Vina-GPU 2.1 further improves the virtual screening runtime and accuracy with the noval RILC-BFGS and GCS mthods based on Vina-GPU 2.0. 
Vina-GPU 2.1 includes AutoDock-Vina-GPU 2.1, QuickVina 2-GPU 2.1 and QuickVina-W-GPU 2.1.
![Vina-GPU2 1-arch](https://github.com/DeltaGroupNJUPT/Vina-GPU-2.1/assets/48940269/3b42ed59-01ce-449a-b203-deea1f0d0a36)



## Virtual Screening Results

* Runtime comparison of Vina-GPU 2.1 on Drugbank library (partial)
![runtime_all_drugbank](https://github.com/DeltaGroupNJUPT/Vina-GPU-2.1/assets/48940269/d728fee5-d4a6-4a16-bbde-cec06a81e38d)

* Accuracy comparison of Vina-GPU 2.1 on Drugbank library (partial)
![vs_accuracy_all_drugbank](https://github.com/DeltaGroupNJUPT/Vina-GPU-2.1/assets/48940269/eacffd1d-cb2a-40d9-9a74-4e8d071aac7b)

## Compiling and Running
### Windows:

1. install [boost library](https://www.boost.org/)  → If using Visual Studio 2022, version ≥1.78.0  is required 
    1. Download the source code from https://www.boost.org/users/download/ and extract
    2. Open Developer Visual Studio Powershell and *cd* to the extracted folder (.\boost_1_xx_0)
    3. **.\bootstrap.bat**
    4. Compile ***stage\lib*** libraries with: 
        
        ```cpp
        .\b2 toolset=msvc-14.3 runtime-link=static threading=multi variant=release address-model=64
        ```
        
    5. vc143-mt-sgd-x64-1_XX libraries will be compiled
2. install [CUDA Toolkit](https://developer.nvidia.com/cuda-downloads) (current version: v12.2) if you are using NVIDIA GPU cards
    
    **Note**: the OpenCL library can be found in CUDA installation path for NVIDIA or in the driver installation path for AMD
    
    ### Visual Studio:
    
3. Create a new Project on Visual Studio: C++ language, Console application (Hello World template), choosing a location for the “Project Folder”
4. Right-click on the project name (Solution Explorer panel) → **Properties.** Set Configuration to Release and Platform to x64.
5. **C/C++ → General**
6. add `$(ONE_OF_VINA_GPU_2_1_METHODS)/lib` `$(ONE_OF_VINA_GPU_2_1_METHODS)/OpenCL/inc` `$(YOUR_BOOST_LIBRARY_PATH)` `$(YOUR_BOOST_LIBRARY_PATH)/boost` `$(YOUR_CUDA_TOOLKIT_LIBRARY_PATH)/CUDA/v1x.x/include` in the include directories
7. **C/C++ → Preprocessor**
8. Add `NVIDIA_PLATFORM` `OPENCL_3_0` `WINDOWS` `SMALL_BOX` in the preprocessor definitions
9. Add `_SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING` and `BOOST_TIMER_ENABLE_DEPRECATED` to disable the warning related to the deprecated *experimental::filesystem* and *timer* libraries from boost
10. Additionally, the error from deprecated **OpenCL** functions may be disabled with `CL_USE_DEPRECATED_OPENCL_1_2_APIS`
11. if you want to compile the binary kernel file on the fly, add `BUILD_KERNEL_FROM_SOURCE` in the preprocessor definitions
12. **C/C++ → Code Generation**
13. Set Runtime Library to Multi-threaded (/MT) → This option depends on the settings used for compiling Boost/stage/lib (variant=release threading=multi runtime-link=static)
14. **Configuration Properties → Debugging**
15. add `-config=$(ONE_OF_VINA_GPU_2_1_METHODS)/input_file_example/2bm2_config.txt` in the command arguments
16. **Configuration Properties → General**
17. Set C++ Language Standard to ISO C++17
18. **Linker → General**
19. add `$(YOUR_BOOST_LIBRARY_PATH)/stage/lib` `$(YOUR_CUDA_TOOLKIT_PATH)/CUDA/lib/x64`in the additional libraries
20. **Linker → Input**
21. add `OpenCL.lib` in the additional dependencies
22. **Click OK**
23. Delete template files (.h and .cpp) from the Solution Explorer
24. All source files (.cpp) and header files (.h) (from `$(ONE_OF_VINA_GPU_2_1_METHODS)/lib` `$(ONE_OF_VINA_GPU_2_1_METHODS)/main`, and `$(ONE_OF_VINA_GPU_2_1_METHODS)/OpenCL/inc`) must be placed **inside** the corresponding folders (header and source) on Visual Studio Solution Explorer. This step is necessary to avoid LINK errors during compilation (e.g. unresolved symbol)
25. **If using boost ≥ 1.85.0 → Edit main.cpp:**

```cpp
//#include <boost/filesystem/convenience.hpp> comment out this line
```

1. Build (Ctrl+B)
2. If the compilation is succesful, the resulting file (.exe) will be placed inside the `‘Project Folder’\x64\Debug\'Project Name'.exe` 

**Note**: ensure the line ending are CLRF

### Generating the Kernel Files on the fly:

1. Copy the .exe to the `$(ONE_OF_VINA_GPU_2_1_METHODS)` folder
2. Set the **—opencl_binary_path** option on the ./input_file_example/2bm2_config.txt to the current `$(ONE_OF_VINA_GPU_2_1_METHODS)` folder
3. On PowerShell, execute `./'Project Name'.exe --config ./input_file_example/2bm2_config.txt`
4. Kernel1_Opt.bin and Kernel2_Opt.bin will be compiled into the `$(ONE_OF_VINA_GPU_2_1_METHODS)` folder
5. The program may be recompiled again without the `BUILD_KERNEL_FROM_SOURCE` option, since the Kernel files only need to be compiled once

### Linux
**Note**: At least 8M stack size is needed. To change the stack size, use `ulimit -s 8192`.
1. install [boost library](https://www.boost.org/) (current version is 1.77.0)
2. install [CUDA Toolkit](https://developer.nvidia.com/cuda-downloads) (current version: v12.2) if you are using NVIDIA GPU cards

    **Note**: OpenCL library can be usually in `/usr/local/cuda` (for NVIDIA GPU cards)
3. `cd` into one of the three methods of Vina-GPU 2.1 (`$(ONE_OF_VINA_GPU_2_1_METHODS)`)
4. change the `BOOST_LIB_PATH` and `OPENCL_LIB_PATH` accordingly in `Makefile`
5. set GPU platform `GPU_PLATFORM` and OpenCL version `OPENCL_VERSION` in `Makefile`. some options are given below:

    **Note**: `-DOPENCL_3_0` is highly recommended in Linux, please avoid using `-OPENCL_1_2` in the Makefile setting. To check the OpenCL version on a given platform, use `clinfo`.
    |Macros|Options|Descriptions|
    |--|--|--|	
    |GPU_PLATFORM|-DNVIDIA_PLATFORM / -DAMD_PLATFORM|NVIDIA / AMD GPU platform
    |  OPENCL_VERSION | -DOPENCL_3_0 / -OPENCL_2_0|OpenCL version 2.1 / 2.0
    
6. type `make clean` and `make source` to build `$(ONE_OF_VINA_GPU_2_1_METHODS)` that compile the kernel files on the fly (this would take some time at the first use)
7. after a successful compiling, `$(ONE_OF_VINA_GPU_2_1_METHODS)` can be seen in the directory 
8. change `--opencl_binary_path` in the `./input_file_example/2bm2_config.txt` accordingly and type `$(ONE_OF_VINA_GPU_2_1_METHODS) --config ./input_file_example/2bm2_config.txt` to run one of the Vina-GPU 2.1 method
9. once you successfully run `$(ONE_OF_VINA_GPU_2_1_METHODS)`, its runtime can be further reduced by typing `make clean` and `make` to build it without compiling kernel files (but make sure the `Kernel1_Opt.bin` file and `Kernel2_Opt.bin` file is located in the dir specified by `--opencl_binary_path`)
10. other compile options: 

|Options| Description|
|--|--|
| -g | debug|
|-DTIME_ANALYSIS|output runtime analysis in `gpu_runtime.log`|
|-DDISPLAY_ADDITION_INFO|print addition information

## Enlarge the docking box
The docking box now can be enlarged by

1. Change `-DSMALL_BOX` into `-DLARGE_BOX` in `Makefile`
2. Type `make source` and `$(ONE_OF_VINA_GPU_2_1_METHODS) --config ./input_file_example/2bm2_config.txt`
3. Once the tutorial docking is finished, type `make clean` and `make`
4. Now you can enlarge the docking box `--size_x/y/z` accordingly (see **Limitation** below)

## Structure Optimization
|Optimization|Methods|Reference|Documentation
|--|--|--|--|
|Receptor Preparation|cross-docking| [origin paper](https://doi.org/10.1016/j.bmc.2022.116686) | [Doc](chrome-extension://efaidnbmnnnibpcajpcglclefindmkaj/https://www.biorxiv.org/content/10.1101/2023.11.04.565429v1.full.pdf)
|Binding Pocket Prediction|COACH-D|[origin paper](https://doi.org/10.1093/nar/gky439) | [Doc](https://yanglab.qd.sdu.edu.cn/COACH-D/help/)
|Ligand Optimization| Gypsum-DL | [origin paper](https://doi.org/10.1186/s13321-019-0358-3) | [Doc](https://github.com/durrantlab/gypsum_dl/blob/main/README.md)

## Usage
|Arguments| Description|Default value
|--|--|--|
|--config | the config file (in .txt format) that contains all the following arguments for the convenience of use| no default
| --receptor | the recrptor file (in .pdbqt format)| no default
|--ligand_directory| this path specifies the directory of all the input ligands(in .pdbqt format) | no default
|--output_directory| this path specifies the directory of the output ligands | no default
|--lbfgs| `--rilc_bfgs 0` turns off the RILC-BFGS, `--rilc_bfgs 1` turns on the RILC-BFGS` | `--rilc_bfgs 1`
|--thread| the scale of parallelism | 5000 for quickvina2-gpu 2.1, 8000 for others
|--search_depth| the number of searching iterations in each docking lane| heuristically determined
|--center_x/y/z|the center of searching box in the receptor|no default
|--size_x/y/z|the volume of the searching box|no default 
|--opencl_binary_path| this path specifies the directory of the kernel path | no default

## Limitation
|Arguments| Description|Limitation
|--|--|--|
|--thread| the scale of parallelism (docking lanes)| preferably less than 10000
|--size_x/y/z|the volume of the searching box |less than 100/100/100 for AutoDock-Vina-GPU 2.1 and 70/70/70 for other two variants

## Citation
* Tang, Shidi, et al. "Vina-GPU 2.1: towards further optimizing docking speed and precision of AutoDock Vina and its derivatives." IEEE/ACM Transactions on Computational Biology and Bioinformatics (2024).
* Ding, Ji, et al. "Vina-GPU 2.0: further accelerating AutoDock Vina and its derivatives with graphics processing units." Journal of chemical information and modeling 63.7 (2023): 1982-1998.
* Tang, Shidi et al. “Accelerating AutoDock Vina with GPUs.” Molecules (Basel, Switzerland) vol. 27,9 3041. 9 May. 2022, doi:10.3390/molecules27093041
* Trott, Oleg, and Arthur J. Olson. "AutoDock Vina: improving the speed and accuracy of docking with a new scoring function, efficient optimization, and multithreading." Journal of computational chemistry 31.2 (2010): 455-461.
* Hassan, N. M. , et al. "Protein-Ligand Blind Docking Using QuickVina-W With Inter-Process Spatio-Temporal Integration." Scientific Reports 7.1(2017):15451.
* Amr Alhossary, Stephanus Daniel Handoko, Yuguang Mu, and Chee-Keong Kwoh. "Fast, accurate, and reliable molecular docking with QuickVina 2. " Bioinformatics (2015): 2214–2216.
